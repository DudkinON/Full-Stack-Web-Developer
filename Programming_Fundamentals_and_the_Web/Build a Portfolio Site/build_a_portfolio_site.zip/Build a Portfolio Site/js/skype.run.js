/**
 * Created by Owner on 7/23/2017.
 */
Skype.ui({
    "name": "chat",
    "element": "SkypeButton_Call_sumonix_1",
    "participants": ["sumonix"],
    "imageColor": "white",
});